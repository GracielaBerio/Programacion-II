/* Fundamentación
 * Se generaron números aleatorios con la clase “Random” y se fueron acumulando en una variable. Dentro del bloque de repetición se comprobaba si eran pares o impares. Sumando los impares aparte, donde la suma se detiene cuando supera un total de 25. 
 */

package com.mycompany.desafio3;

/**
 *
 * @author grabe
 */
import java.util.Random;

public class Desafio3 {
    public static void main(String[] args) {
        Random random = new Random(); // Generador de números aleatorios
        int sumaImpares = 0; // Acumulador de números impares

        System.out.println("Secuencia de números generados:");

        // Bucle que suma los números impares hasta el valor 25
        while (sumaImpares <= 25) {
            int numero = random.nextInt(11); // Número aleatorio entre 0 y 10

            // Verificación de paridad
            if (numero % 2 == 0) {
                System.out.println(numero + " es par");
            } else {
                System.out.println(numero + " es impar");
                sumaImpares += numero; // Acumula solo los impares
            }
        }

        // Mostrar resultado final
        System.out.println("\n La suma de los números impares es: " + sumaImpares);
    }
}

