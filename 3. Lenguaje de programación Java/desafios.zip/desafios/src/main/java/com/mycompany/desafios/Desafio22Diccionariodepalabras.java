/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.desafios;

import java.util.TreeMap;

/**
 *
 * @author grabe
 */
public class Desafio22Diccionariodepalabras {
    
    public static void main(String[] args) {
        TreeMap<String, String> diccionario = new TreeMap<>();
        diccionario.put("apple", "manzana");
        diccionario.put("dog", "perro");
        diccionario.put("house", "casa");

        System.out.println("Diccionario inglés-español:");
        for (String palabra : diccionario.keySet()) {
            System.out.println(palabra + " = " + diccionario.get(palabra));
        }
    }
}
