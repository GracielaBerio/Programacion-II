/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.desafios;

import java.util.ArrayList;
/**
 *
 * @author grabe
 */
public class Desafio18Listadeenteros {
    
    public static void main(String[] args) {
        ArrayList<Integer> numeros = new ArrayList<>();
        numeros.add(10);
        numeros.add(20);
        numeros.add(30);
        numeros.add(40);

        double suma = 0;
        for (int n : numeros) {
            suma += n;
        }
        double promedio = suma / numeros.size();

        System.out.println("Números: " + numeros);
        System.out.println("Promedio = " + promedio);
    }
}
