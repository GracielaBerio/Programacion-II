/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.desafios;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author grabe
 */
public class Desafio17Listadenombres {
    
    public static void main(String[] args) {
        ArrayList<String> nombres = new ArrayList<>();
        Scanner sc = new Scanner(System.in);

        System.out.println("Ingrese nombres y la palabra fin para terminar):");
        String nombre;
        while (!(nombre = sc.nextLine()).equalsIgnoreCase("fin")) {
            nombres.add(nombre);
        }

        System.out.println("\nLista de nombres:");
        for (String n : nombres) {
            System.out.println(n);
        }
    }
}
