/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.desafios;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author grabe
 */
public class Desafio23PromedioconIterator {
    
    public static void main(String[] args) {
        ArrayList<Double> precios = new ArrayList<>();
        precios.add(100.5);
        precios.add(200.75);
        precios.add(50.25);

        double suma = 0;
        Iterator<Double> it = precios.iterator();
        while (it.hasNext()) {
            suma += it.next();
        }

        double promedio = suma / precios.size();
        System.out.println("Precios: " + precios);
        System.out.println("Promedio = " + promedio);
    }
}
