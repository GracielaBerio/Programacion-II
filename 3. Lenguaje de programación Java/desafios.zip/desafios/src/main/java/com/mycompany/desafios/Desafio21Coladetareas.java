/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.desafios;

import java.util.LinkedList;

/**
 *
 * @author grabe
 */
public class Desafio21Coladetareas {
    
    public static void main(String[] args) {
        LinkedList<String> tareas = new LinkedList<>();
        tareas.add("Hacer compras");
        tareas.add("Estudiar Java");
        tareas.add("Lavar la ropa");

        System.out.println("Cola de tareas: " + tareas);

        String primera = tareas.poll(); // extrae la primera
        System.out.println("Tarea realizada: " + primera);
        System.out.println("Siguiente en la cola: " + tareas.peek());
    }
}
