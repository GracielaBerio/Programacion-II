/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.desafios;

import java.util.HashSet;

/**
 *
 * @author grabe
 */
public class Desafio20Conjuntodeciudades {
    
    public static void main(String[] args) {
        HashSet<String> ciudades = new HashSet<>();
        ciudades.add("Montevideo");
        ciudades.add("Colonia");
        ciudades.add("Salto");
        ciudades.add("Paysandú");

        System.out.println("Ciudades:");
        for (String c : ciudades) {
            System.out.println(c);
        }

        if (ciudades.contains("Colonia")) {
            System.out.println("✅ Colonia está en el conjunto.");
        } else {
            System.out.println("❌ Colonia no está en el conjunto.");
        }
    }
}
