/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.desafios;

import java.util.HashMap;

/**
 *
 * @author grabe
 */
public class Desafio19Catalogodeproductos {
    

    public static void main(String[] args) {
        HashMap<Integer, String> productos = new HashMap<>();
        productos.put(101, "Laptop");
        productos.put(102, "Mouse");
        productos.put(103, "Teclado");

        System.out.println("Catálogo de productos:");
        for (Integer codigo : productos.keySet()) {
            System.out.println("Código: " + codigo + " - Producto: " + productos.get(codigo));
        }
    }
}
